As part of my Python Programming internship at CodeAlpha, my first task included the following instructions:
"Design a text-based Hangman game. The program selects a random word, and the player guesses one letter at a time to uncover the word. You can set a limit on the number of incorrect guesses allowed."

The file "HangmanGame.py" demonstrates how I achieved that.
